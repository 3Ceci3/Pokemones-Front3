public interface Comparable {
    public void comparar();
}
