import java.util.List;

public class Main {


    public static void main(String[] args) {




        Capitan capitan = new Capitan("Teo", "Nuñez",11111);

    }
}